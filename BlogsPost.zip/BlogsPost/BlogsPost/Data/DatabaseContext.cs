﻿using BlogsPost.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace BlogsPost.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options) { }
        public DbSet<BlogPosts> BlogPosts { get; set; }
    }
}
