﻿using BlogsPost.Data;
using BlogsPost.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BlogsPost.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class postsController : ControllerBase
    {
        DatabaseContext _db;

        public postsController(DatabaseContext db, IHttpContextAccessor httpContextAccessor)
        {
            _db = db;
        }
        [HttpGet("{Id:int}")]
        public IActionResult posts(int Id)
        {
            var Blogs = _db.BlogPosts.Where(x => x.Id == Id);
            return Ok(Blogs);


        }
        [HttpGet]
        public async Task<IActionResult> posts()
        {

            var BlogsList = _db.BlogPosts.ToList();
            return Ok(BlogsList);


        }
        [HttpPost]
        public IActionResult posts(BlogPosts blogPosts)
        {

            _db.BlogPosts.Add(blogPosts);
            _db.SaveChanges();
            return Ok("Record has been added");


        }
        [HttpPut]
        public IActionResult updateposts(BlogPosts blogPosts)
        {
            _db.BlogPosts.Update(new BlogPosts
            {
                Id = blogPosts.Id,
                Title = blogPosts.Title,
                Author = blogPosts.Author,
                Content = blogPosts.Quote
            });
            return Ok("Record has been updated");


        }
    }
}
