﻿using BlogsPost.Model;
using BlogsPost.Model.Log;
using BlogsPost.Model.Response;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;

namespace BlogsPost.Helpers
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private AppSettings _appSettings = new AppSettings();
        private Logger _logger;

        public ErrorHandlerMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            configuration.GetSection("AppSettings").Bind(_appSettings);
            _logger = Logger.GetInstance(_appSettings.FileLoggerPath);
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                var response = context.Response;
                response.ContentType = "application/json";
                bool isDBLog = true;

                switch (error)
                {
                    case AppException e:
                        // custom application error
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        isDBLog = e.IsDBLog;
                        break;
                    case KeyNotFoundException e:
                        // not found error
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                        break;
                    default:
                        // unhandled error
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        break;
                }

                var errResponse = new BaseResponse
                {
                    Code = response.StatusCode,
                    Message = error.Message,
                    Success = false
                };
                try
                {
                    if (isDBLog)
                    {
                        Exception ex = error.GetBaseException();
                        var request = new ErrorLogRequest();
                        request.ErrorLog = new ErrorLog
                        {
                            ErrorMessage = ex.GetBaseException().Message,
                            StackTrace = ex.StackTrace,
                            ControllerName = context.Request.RouteValues["controller"]?.ToString(),
                            ActionName = context.Request.RouteValues["action"]?.ToString()
                        };
                        //at this time no table exist for error log in DB so we are adding file
                    _logger.WriteLogWithLock(error, "WebApi -> " + context.Request.RouteValues["controller"]?.ToString() + "/" + context.Request.RouteValues["action"]?.ToString());

                    }
                }
                catch { }
                try
                {
                    _logger.WriteLogWithLock(error, "WebApi -> " + context.Request.RouteValues["controller"]?.ToString() + "/" + context.Request.RouteValues["action"]?.ToString());
                }
                catch { }

                var result = JsonSerializer.Serialize(errResponse);
                await response.WriteAsync(result);
            }
        }
    }
}
