﻿namespace BlogsPost.Helpers;
public static class MiddlewareExtensions
{
    public static void RegisterMiddlewares(this WebApplication app)
    {
       
        // global error handler
        app.UseMiddleware<ErrorHandlerMiddleware>();
    }
}

