﻿using BlogsPost.Model;
using System.Reflection;

namespace BlogsPost.Helpers;

public static class ServiceExtensions
{
    public static void RegisterServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        //services.AddSingleton<IContextManager, ContextManager>();
        //services.AddSingleton<IConfigManager, ConfigManager>();

        #region Application Services

        // Define types that need matching
        Type scopedService = typeof(ScopedServiceAttribute);
        Type singletonService = typeof(SingletonServiceAttribute);
        Type transientService = typeof(TransientServiceAttribute);

        var path = AppContext.BaseDirectory;
        var directory = new DirectoryInfo(path);

        if (directory.Exists)
        {
            var dllFiles = directory.GetFiles("VasTek*.dll");
            var types = dllFiles.Select(x => Assembly.Load(AssemblyName.GetAssemblyName(x.FullName)))
                .SelectMany(x => x.GetTypes())
                .Where(p => (p.IsDefined(scopedService, true)
                    || p.IsDefined(transientService, true)
                    || p.IsDefined(singletonService, true))
                    && !p.IsInterface)
                .Select(s => new
                {
                    Service = s.GetInterface($"I{s.Name}"),
                    Implementation = s
                }).Where(x => x.Service != null);

            foreach (var type in types)
            {
                if (type.Implementation.IsDefined(scopedService, false))
                {
                    services.AddScoped(type.Service, type.Implementation);
                }

                if (type.Implementation.IsDefined(transientService, false))
                {
                    services.AddTransient(type.Service, type.Implementation);
                }

                if (type.Implementation.IsDefined(singletonService, false))
                {
                    services.AddSingleton(type.Service, type.Implementation);
                }
            }
        }

        #endregion
    }

}
