﻿using System.Globalization;

namespace BlogsPost.Model;

public class AppException : Exception
{
    public AppException() : base() { }

    public AppException(string message) : base(message) { }
    public AppException(string message, bool isDBLog) : base(message) { _isDBLog = isDBLog; }

    public AppException(string message, params object[] args)
        : base(String.Format(CultureInfo.CurrentCulture, message, args))
    {
    }
    public AppException(string message, bool isDBLog, params object[] args)
        : base(String.Format(CultureInfo.CurrentCulture, message, args))
    {
        _isDBLog = isDBLog;
    }

    private bool _isDBLog = true;
    public bool IsDBLog { get { return _isDBLog; } }
}
