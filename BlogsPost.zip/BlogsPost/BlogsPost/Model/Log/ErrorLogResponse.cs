﻿using BlogsPost.Model.Response;

namespace BlogsPost.Model.Log
{
    public class ErrorLogResponse : BaseResponse
    {
    }
}
