﻿namespace BlogsPost.Model.Log;


public interface IErrorLogService
{
    public Task<ErrorLogResponse> Log(ErrorLogRequest request);
}