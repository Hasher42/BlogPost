﻿namespace BlogsPost.Model.Log;

public class ErrorLogRequest
{
    public Exception Exception { get; set; }
    public ErrorLog ErrorLog { get; set; }
    public bool IsDBLog { get; set; }
}