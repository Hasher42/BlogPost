﻿namespace BlogsPost.Model.Log;
public class Logger
{
    private static Logger? _instance;

    protected Logger() { }
    protected Logger(string logPath)
    {
        LogPath = logPath;
    }

    public static Logger GetInstance(string logPath)
    {
        if (_instance == null)
        {
            _instance = new Logger(logPath);
        }

        return _instance;
    }

    #region Properties
    private static string LogPath { get; set; }

    private static string LogDateTime
    {
        get
        {
            return DateTime.Now.ToString("yyyyMMdd-HH:mm:ss");
        }
    }
    private static string LogDirectoryPath
    {
        get
        {
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            return LogPath;
        }
    }

    private static string LogFileName
    {
        get
        {
            return DateTime.Now.ToString("yyyyMMdd") + ".txt";
        }
    }
    private static string LogFilePath
    {
        get
        {
            string logFilePath = LogDirectoryPath + LogFileName;
            if (!File.Exists(logFilePath))
            {
                FileStream fsLogFile = File.Create(logFilePath);
                fsLogFile.Flush();
                fsLogFile.Close();
            }

            return logFilePath;
        }
    }

    private static readonly object _objLock = new object();

    #endregion

    #region Methods

    public void WriteLog(Exception exception)
    {
        try
        {
            using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
            {
                swLogFile.WriteLine(LogDateTime + " [ERROR] (" + exception.Source.Trim() + ") " + exception.GetBaseException().Message.Trim() + ",  StackTrace:" + exception.StackTrace + ";" + Environment.NewLine);
                swLogFile.Flush();
                swLogFile.Close();
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void WriteLogWithLock(Exception exception)
    {
        try
        {
            lock (_objLock)
            {
                using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
                {
                    swLogFile.WriteLine(LogDateTime + " [ERROR] (" + exception.Source.Trim() + ") " + exception.GetBaseException().Message.Trim() + ",  StackTrace:" + exception.StackTrace + ";" + Environment.NewLine);
                    swLogFile.Flush();
                    swLogFile.Close();
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void WriteLog(Exception exception, string methodName)
    {
        try
        {
            using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
            {
                swLogFile.WriteLine(LogDateTime + " [ERROR] (" + methodName + ") " + exception.GetBaseException().Message.Trim() + ",  StackTrace:" + exception.StackTrace + ";" + Environment.NewLine);
                swLogFile.Flush();
                swLogFile.Close();
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void WriteLogWithLock(Exception exception, string methodName)
    {
        try
        {
            lock (_objLock)
            {
                using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
                {
                    swLogFile.WriteLine(LogDateTime + " [ERROR] (" + methodName + ") " + exception.GetBaseException().Message.Trim() + ",  StackTrace:" + exception.StackTrace + ";" + Environment.NewLine);
                    swLogFile.Flush();
                    swLogFile.Close();
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void WriteLog(string message)
    {
        try
        {
            using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
            {
                swLogFile.WriteLine(LogDateTime + " [MESSAGE] " + message + ";");
                swLogFile.Flush();
                swLogFile.Close();
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void WriteLogWithLock(string message)
    {
        try
        {
            lock (_objLock)
            {
                using (StreamWriter swLogFile = new StreamWriter(LogFilePath, true))
                {
                    swLogFile.WriteLine(LogDateTime + " [MESSAGE] " + message + ";");
                    swLogFile.Flush();
                    swLogFile.Close();
                }
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void DeletePreviousLogs(int noOfDays)
    {
        try
        {
            if (Directory.Exists(LogDirectoryPath))
            {
                var files = new DirectoryInfo(LogDirectoryPath).GetFiles();
                foreach (var file in files)
                {
                    if (DateTime.Now - file.LastWriteTime > TimeSpan.FromDays(noOfDays))
                    {
                        File.Delete(file.FullName);
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }

    #endregion
}