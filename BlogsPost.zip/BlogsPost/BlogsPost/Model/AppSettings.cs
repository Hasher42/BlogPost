﻿namespace BlogsPost.Model
{
    public class AppSettings
    {
        public Database Database { get; set; }
        public Keys Keys { get; set; }
        public CORS CORS { get; set; }
        public Jwt Jwt { get; set; }
        public ExportData ExportData { get; set; }
        public string HtmlTemplatePath { get; set; }
        public string FileLoggerPath { get; set; }
    }

    public class Keys
    {
        public string ApiPath { get; set; }
        public string Secret { get; set; }
        public string ApiKey { get; set; }
    }

    public class Jwt
    {
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string Key { get; set; }
    }

    public class CORS
    {
        public string AllowedHosts { get; set; }
        public string AllowedHeaders { get; set; }
        public string AllowedMethods { get; set; }
    }

    #region File Export (Pdf / Excel)

    public class ExportData
    {
        public bool IsRelativePath { get; set; }
        public ExportSetting Excel { get; set; }
        public ExportSetting Pdf { get; set; }
    }

    public class ExportSetting
    {
        public string RootDirectory { get; set; }
    }

    #endregion

    #region DB Connection String

    public class Database : DBString { }

    public class DBString
    {
        public string DbConnectionString { get; set; }
        public string ProviderName { get; set; }
    }

    #endregion
}
